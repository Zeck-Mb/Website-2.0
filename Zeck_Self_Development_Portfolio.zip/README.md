# Zeck Andrei Belino — Self-Development Portfolio

Open `index.html` in a browser to view the portfolio.

The portfolio is built with HTML and CSS only:

- `index.html` — page structure and content
- `style.css` — responsive visual design
- `assets/` — the attached project PDFs, business card, and preview images

To publish it, upload `index.html`, `style.css`, and the complete `assets` folder to GitHub Pages, Netlify, or another static hosting service.
